/*-
 * #%L
 * Spark-based parallel BigStitcher project.
 * %%
 * Copyright (C) 2021 - 2024 Developers.
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 2 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/gpl-2.0.html>.
 * #L%
 */
package net.preibisch.bigstitcher.spark.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import mpicbg.spim.data.SpimData;
import mpicbg.spim.data.sequence.ViewDescription;
import mpicbg.spim.data.sequence.ViewId;
import net.preibisch.bigstitcher.spark.SparkAffineFusion.DataTypeFusion;
import net.preibisch.mvrecon.fiji.spimdata.SpimData2;
import net.preibisch.mvrecon.fiji.spimdata.boundingbox.BoundingBox;
import net.preibisch.mvrecon.process.boundingbox.BoundingBoxTools;

public class Import {

	public static BoundingBox getBoundingBox(
			final SpimData2 data,
			final List< ViewId > viewIds,
			final String boundingBoxName )
			throws IllegalArgumentException
	{
		BoundingBox bb = null;

		if ( boundingBoxName == null )
		{
			bb = BoundingBoxTools.maximalBoundingBox( data, viewIds, "All Views" );
		}
		else
		{
			final List<BoundingBox> boxes = BoundingBoxTools.getAllBoundingBoxes( data, null, false );

			for ( final BoundingBox box : boxes )
				if ( box.getTitle().equals( boundingBoxName ) )
					bb = box;

			if ( bb == null )
			{
				throw new IllegalArgumentException( "Bounding box '" + boundingBoxName + "' not present in XML." );
			}
		}

		return bb;
	}

	public static void validateInputParameters(
			final DataTypeFusion datatype,
			final Double minIntensity,
			final Double maxIntensity )
			throws IllegalArgumentException
	{
		if ( ( datatype == DataTypeFusion.UINT8 || datatype == DataTypeFusion.UINT16 ) && (minIntensity == null || maxIntensity == null ) ) {
			throw new IllegalArgumentException( "When selecting UINT8 or UINT16 you need to specify minIntensity and maxIntensity." );
		}
	}

	public static void validateInputParameters(
			final String[] vi,
			final String angleIds, 
			final String channelIds,
			final String illuminationIds,
			final String tileIds,
			final String timepointIds )
			throws IllegalArgumentException
	{
		if ( vi != null &&
			 ( angleIds != null || tileIds != null || illuminationIds != null || timepointIds != null || channelIds != null ) ) {
			throw new IllegalArgumentException( "You can only specify ViewIds (-vi) OR angles, channels, illuminations, tiles, timepoints." );
		}
	}

	public static ArrayList< ViewId > createViewIds(
			final SpimData data,
			final String[] vi,
			final String angleIds, 
			final String channelIds,
			final String illuminationIds,
			final String tileIds,
			final String timepointIds )
	{
		final ArrayList< ViewId > viewIds;

		if ( vi != null )
		{
			System.out.println( "Parsing selected ViewIds ... ");
			ArrayList<ViewId> parsedViews = Import.getViewIds( vi );
			viewIds = Import.getViewIds( data, parsedViews );
			System.out.println( "Warning: only " + viewIds.size() + " of " + parsedViews.size() + " that you specified exist and are present.");
		}
		else if ( angleIds != null || tileIds != null || illuminationIds != null || timepointIds != null || channelIds != null )
		{
			System.out.print( "Parsing selected angle ids ... ");
			final HashSet<Integer> a = Import.parseIdList( angleIds );
			System.out.println( a != null ? a : "all" );

			System.out.print( "Parsing selected channel ids ... ");
			final HashSet<Integer> c = Import.parseIdList( channelIds );
			System.out.println( c != null ? c : "all" );

			System.out.print( "Parsing selected illumination ids ... ");
			final HashSet<Integer> i = Import.parseIdList( illuminationIds );
			System.out.println( i != null ? i : "all" );

			System.out.print( "Parsing selected tile ids ... ");
			final HashSet<Integer> ti = Import.parseIdList( tileIds );
			System.out.println( ti != null ? ti : "all" );

			System.out.print( "Parsing selected timepoint ids ... ");
			final HashSet<Integer> tp = Import.parseIdList( timepointIds );
			System.out.println( tp != null ? tp : "all" );

			viewIds = Import.getViewIds( data, a, c, i, ti, tp );
		}
		else
		{
			// get all
			viewIds = Import.getViewIds( data );
		}

		return viewIds;
	}

	public static ArrayList< ViewId > getViewIds( final SpimData data )
	{
		// select views to process
		final ArrayList<ViewId> viewIds = new ArrayList<>(data.getSequenceDescription().getViewDescriptions().values());

		// filter not present ViewIds
		SpimData2.filterMissingViews( data, viewIds );

		return viewIds;
	}

	public static ArrayList< ViewId > getViewIds( final SpimData data, final ArrayList<ViewId> vi )
	{
		// select views to process
		final ArrayList< ViewId > viewIds = new ArrayList<>();

		for ( final ViewDescription vd : data.getSequenceDescription().getViewDescriptions().values() )
		{
			for ( final ViewId v : vi )
				if ( vd.getTimePointId() == v.getTimePointId() && vd.getViewSetupId() == v.getViewSetupId() )
					viewIds.add( vd );
		}

		// filter not present ViewIds
		SpimData2.filterMissingViews( data, viewIds );

		return viewIds;
	}

	public static ArrayList< ViewId > getViewIds(
			final SpimData data,
			final HashSet<Integer> a,
			final HashSet<Integer> c,
			final HashSet<Integer> i,
			final HashSet<Integer> ti,
			final HashSet<Integer> tp )
	{
		// select views to process
		final ArrayList< ViewId > viewIds = new ArrayList<>();

		for ( final ViewDescription vd : data.getSequenceDescription().getViewDescriptions().values() )
		{
			if (
					( a == null || a.contains( vd.getViewSetup().getAngle().getId() )) &&
					( c == null || c.contains( vd.getViewSetup().getChannel().getId() )) &&
					( i == null || i.contains( vd.getViewSetup().getIllumination().getId() )) &&
					( ti == null || ti.contains( vd.getViewSetup().getTile().getId() )) &&
					( tp == null || tp.contains( vd.getTimePointId() )) )
			{
				viewIds.add( vd );
			}
		}

		// filter not present ViewIds
		SpimData2.filterMissingViews( data, viewIds );

		return viewIds;
	}

	public static HashSet< Integer > parseIdList( String idList )
	{
		if ( idList == null )
			return null;

		idList = idList.trim();

		if ( idList.length() == 0 )
			return null;

		final String[] ids = idList.split( "," );
		final HashSet< Integer > hash = new HashSet<>();

		for (final String id : ids) {
			hash.add(Integer.parseInt(id.trim()));
		}

		return hash;
	}

	public static ArrayList<ViewId> getViewIds( final String[] s )
	{
		final ArrayList<ViewId> viewIds = new ArrayList<>();
		for ( final String s0 : s )
			viewIds.add( getViewId( s0 ) );
		return viewIds;
	}

	public static int[] csvStringToIntArray(final String csvString) {
		return Arrays.stream(csvString.split(",")).map( st -> st.trim() ).mapToInt(Integer::parseInt).toArray();
	}

	public static double[] csvStringToDoubleArray(final String csvString) {
		return Arrays.stream(csvString.split(",")).map( st -> st.trim() ).mapToDouble(Double::parseDouble).toArray();
	}

	/**
	 * converts a String like '1,1,1; 2,2,1; 4,4,1; 8,8,2' to downsampling levels in int[][]
	 * @param csvString
	 * @return
	 */
	public static int[][] csvStringToDownsampling(final String csvString) {

		final String[] split = csvString.split(";");

		final int[][] downsampling = new int[split.length][];
		for ( int i = 0; i < split.length; ++i )
			downsampling[ i ] = Arrays.stream(split[ i ].split(",")).map( st -> st.trim() ).mapToInt(Integer::parseInt).toArray();

		return downsampling;
	}

	/**
	 * converts a List of Strings like '[1,1,1][ 2,2,1][ 4,4,1 ][ 8,8,2] to downsampling levels in int[][]
	 * @param csvString
	 * @return
	 */
	public static int[][] csvStringListToDownsampling(final List<String> csvString)
	{
		if ( csvString == null || csvString.size() < 1 )
		{
			System.out.println( "List of strings for downsampling is empty/null.");
			return null;
		}
		
		final int[][] downsampling = new int[csvString.size()][];
		for ( int i = 0; i < csvString.size(); ++i )
		{
			downsampling[ i ] = Arrays.stream(csvString.get( i ).split(",")).map( st -> st.trim() ).mapToInt(Integer::parseInt).toArray();
			if ( downsampling[ i ].length != 3 )
			{
				System.out.println( "dimensions of downsampling entry is not 3: " + csvString.get( i ) );
				return null;
			}
		}

		if ( !Arrays.equals( downsampling[ 0 ], new int[] { 1, 1, 1 }))
		{
			System.out.println( "first entry is not [1,1,1], but must be: " + csvString.get( 0 ) );
			return null;
		}

		return downsampling;
	}

	/**
	 * tests that the first downsampling is [1,1,....1]
	 *
	 * @param downsampling
	 * @return
	 */
	public static boolean testFirstDownsamplingIsPresent(final int[][] downsampling)
	{
		if ( downsampling.length > 0 && Arrays.stream(downsampling[0]).boxed().anyMatch( n -> n == 1 ) && Arrays.stream(downsampling[0]).boxed().distinct().count() == 1 )
			return true;
		else
			return false;
	}

	public static ViewId getViewId(final String bdvString )
	{
		final String[] entries = bdvString.trim().split( "," );
		final int timepointId = Integer.parseInt( entries[ 0 ].trim() );
		final int viewSetupId = Integer.parseInt( entries[ 1 ].trim() );

		return new ViewId(timepointId, viewSetupId);
	}

	/*
	public static String createBDVPath(final String bdvString, final StorageFormat storageType)
	{
		final ViewId viewId = getViewId(bdvString);

		String path = null;

		if ( StorageFormat.N5.equals(storageType) )
		{
			path = "setup" + viewId.getViewSetupId() + "/" + "timepoint" + viewId.getTimePointId() + "/s0";
		}
		else if ( StorageFormat.HDF5.equals(storageType) )
		{
			path = "t" + String.format("%05d", viewId.getTimePointId()) + "/" + "s" + String.format("%02d", viewId.getViewSetupId()) + "/0/cells";
		}
		else
		{
			new RuntimeException( "BDV-compatible dataset cannot be written for " + storageType + " (yet).");
		}

		System.out.println( "Saving BDV-compatible " + storageType + " using ViewSetupId=" + viewId.getViewSetupId() + ", TimepointId=" + viewId.getTimePointId()  );
		System.out.println( "path=" + path );

		return path;
	}*/
}
